import { pricingPlans, createPlanHTML } from './components/pricingPlans.js'

export function setupModal() {
  const modal = document.querySelector('.modal')
  const overlay = document.querySelector('.overlay')
  const openButton = document.querySelector('#openModal')
  const closeButton = document.querySelector('.close-button')

  function openModal() {
    modal.classList.add('active')
    overlay.classList.add('active')
  }

  function closeModal() {
    modal.classList.remove('active')
    overlay.classList.remove('active')
  }

  function handlePlanSelection(e) {
    if (e.target.classList.contains('plan-button')) {
      const planName = e.target.textContent.replace('Choose ', '')
      window.open('https://discord.com/invite/hrhosting', '_blank')
    }
  }

  openButton.addEventListener('click', openModal)
  closeButton.addEventListener('click', closeModal)
  overlay.addEventListener('click', closeModal)
  modal.addEventListener('click', handlePlanSelection)
}