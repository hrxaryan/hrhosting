import './style.css'
import './styles/modal.css'
import './styles/pricing.css'
import './styles/hero.css'
import './styles/features.css'
import './styles/stats.css'
import { setupModal } from './modal.js'
import { pricingPlans, createPlanHTML } from './components/pricingPlans.js'
import { createHeroSection } from './components/Hero.js'
import { createFeaturesSection } from './components/Features.js'
import { createStatsSection } from './components/Stats.js'

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('#app').innerHTML = `
    <div class="background"></div>
    <main class="content">
      ${createHeroSection()}
      ${createFeaturesSection()}
      ${createStatsSection()}
    </main>

    <div class="modal">
      <button class="close-button">&times;</button>
      <h2 style="text-align: center; margin-bottom: 2rem;">Choose Your Plan</h2>
      <div class="pricing-container">
        ${pricingPlans.map(plan => createPlanHTML(plan)).join('')}
      </div>
    </div>
    <div class="overlay"></div>
  `

    // Initialize modal functionality after DOM content is loaded
    setupModal()
})