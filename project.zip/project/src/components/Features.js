export function createFeaturesSection() {
    const features = [
        {
            icon: '🚀',
            title: 'High Performance',
            description: 'Lightning-fast servers with 99.9% uptime guarantee'
        },
        {
            icon: '🛡️',
            title: 'Enterprise Security',
            description: 'Advanced security measures to protect your data'
        },
        {
            icon: '🔧',
            title: '24/7 Support',
            description: 'Round-the-clock technical support and monitoring'
        },
        {
            icon: '💼',
            title: 'Scalable Solutions',
            description: 'Flexible resources that grow with your business'
        }
    ]

    return `
    <div class="features-section">
      <h2 class="section-title">Why Choose Us</h2>
      <div class="features-grid">
        ${features.map(feature => `
          <div class="feature-card">
            <div class="feature-icon">${feature.icon}</div>
            <h3 class="feature-title">${feature.title}</h3>
            <p class="feature-description">${feature.description}</p>
          </div>
        `).join('')}
      </div>
    </div>
  `
}