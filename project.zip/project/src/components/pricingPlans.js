export const pricingPlans = [
  {
    name: 'Starter Plan',
    price: '99₹',
    period: 'month',
    features: [
      'CPU - 100%',
      'RAM - 2GB',
      'SSD - 10GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  },
  {
    name: 'Basic Plan',
    price: '149₹',
    period: 'month',
    features: [
      'CPU - 100%',
      'RAM - 4GB',
      'SSD - 20GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  },
  {
    name: 'Better Plan',
    price: '219₹',
    period: 'month',
    features: [
      'CPU - 200%',
      'RAM - 6GB',
      'SSD - 30GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  },
  {
    name: 'Standard Plan',
    price: '279₹',
    period: 'month',
    features: [
      'CPU - 300%',
      'RAM - 8GB',
      'SSD - 40GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  },
  {
    name: 'Premium Plan',
    price: '359₹',
    period: 'month',
    features: [
      'CPU - 400%',
      'RAM - 12GB',
      'SSD - 50GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  },
  {
    name: 'Legendary Plan',
    price: '429₹',
    period: 'month',
    features: [
      'CPU - 500%',
      'RAM - 16GB',
      'SSD - 80GB',
      'Intel Xeon Gold 6154',
      'India Location',
      '24/7 Online'
    ],
    popular: false
  }
];

export function createPlanHTML(plan) {
  return `
    <div class="plan ${plan.popular ? 'popular' : ''}">
      ${plan.popular ? '<span class="popular-badge">Most Popular</span>' : ''}
      <h3 class="plan-name">${plan.name}</h3>
      <div class="plan-price">
        ${plan.price}<span>/${plan.period}</span>
      </div>
      <ul class="features-list">
        ${plan.features.map(feature => `<li>${feature}</li>`).join('')}
      </ul>
      <button class="plan-button">Choose ${plan.name}</button>
    </div>
  `;
}