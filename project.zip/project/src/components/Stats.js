export function createStatsSection() {
    const stats = [
        { number: '50K+', label: 'Active Users' },
        { number: '99.9%', label: 'Uptime' },
        { number: '24/7', label: 'Support' },
        { number: '15+', label: 'Data Centers' }
    ]

    return `
    <div class="stats-section">
      <div class="stats-grid">
        ${stats.map(stat => `
          <div class="stat-card">
            <div class="stat-number">${stat.number}</div>
            <div class="stat-label">${stat.label}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `
}