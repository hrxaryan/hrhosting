export function createHeroSection() {
    return `
    <div class="hero-section">
      <h1 class="title">HR Hosting</h1>
      <p class="subtitle">Powerful, Reliable, and Secure Cloud Infrastructure</p>
      <div class="button-container">
        <button class="button button-primary" id="openModal">View Plans</button>
        <a href="https://discord.com/invite/hrhosting" target="_blank" class="button button-secondary">Contact Us</a>
      </div>
    </div>
  `
}